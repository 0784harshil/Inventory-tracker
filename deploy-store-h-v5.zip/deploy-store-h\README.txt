===================================================
Store H Sync Agent - Setup Instructions
===================================================

1. Edit config.txt with your database details.
2. Run JD-GURUS-StoreH-Sync.exe.
3. Check agent.log if it closes immediately.
